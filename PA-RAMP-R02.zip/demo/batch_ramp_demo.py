# demo_ramp_batch.py

from pynolca.manifold_reg import *
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import pynolca
import time
import pickle
# load data 

def get_data(dataname):
    if dataname == 'Adult':
        # Adult Data
        X = np.load("datasets/adultdata/adultData.npy")
        X_test = np.load("datasets/adultdata/adultTest.npy")
        y = np.load("datasets/adultdata/adultData_label.npy")
        y_test = np.load("datasets/adultdata/adultTest_label.npy")
        X_orig = np.vstack((X, X_test))
        X_orig = (X_orig - X_orig.mean(axis = 0)) / X_orig.std(axis = 0)
        y_orig = np.hstack((y, y_test))
        
    if dataname == 'intel':
        #inteldata
        df = pd.read_csv("datasets/inteldata/inteldata.csv")
        df = df.sample(n=20000, random_state=1)
        X_orig = np.array(df[df.columns[1:5]])
        X_orig = (X_orig - X_orig.mean(axis = 0)) / X_orig.std(axis = 0)
        y_orig = np.array(df[df.columns[-1]])
    if dataname == 'kdd':
        #KDDdata
        df = pd.read_csv("datasets/KDDdata/KDDdata.csv")
        df = df.sample(n=20000, random_state=1)
        X_orig = np.array(df[df.columns[0:-1]])
        X_orig = (X_orig - X_orig.mean(axis = 0))
        y_orig = np.array(df[df.columns[-1]])
    if dataname == 'letter':
        # Letters Data
        # Character
        X_orig = np.loadtxt('datasets/letter-recognition.data',
                        usecols = (range(1,16)),
                        delimiter=",")
        X_orig = (X_orig - X_orig.mean(axis = 1, keepdims=True)) / X_orig.std(axis = 1, keepdims=True)
        # Load the true labels
        y = np.loadtxt("datasets/letter-recognition.data",
                        usecols = (0,),
                        delimiter=",", dtype='str')

        idx_set = np.array(['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'])
        y_orig = -1 * np.ones(len(y), dtype = np.int16)
        for i in range(len(y)):
            if y[i] in idx_set:
                y_orig[i] = 1
    if dataname == 'occupancy':
        # Occupancy

        df_1 = pd.read_csv("datasets/occupancy/datatraining.txt")
        df_2 = pd.read_csv("datasets/occupancy/datatest.txt")
        df_3 = pd.read_csv("datasets/occupancy/datatest2.txt")

        df = pd.concat([df_1, df_2, df_3], ignore_index=True)

        X_orig = np.array(df[df.columns[1:6]])
        X_orig = (X_orig - X_orig.mean(axis = 0)) / X_orig.std(axis = 0)
        y_orig = np.array(df[df.columns[-1]], dtype=np.int16)
        y_orig = y_orig * 2 - 1
    if dataname == 'RBF':
        # RBF
        df = pd.read_csv("datasets/RandomRBF/RandomRBF_10.csv")
        df = df.sample(n=1000, random_state=1)
        X_orig = np.array(df[df.columns[0:10]])
        y_orig = np.array(df[df.columns[-1]])
    return X_orig,y_orig

# datasets = ['Adult', 'intel', 'kdd', 'letter', 'occupancy', 'RBF']
datasets = ['letter']

for name in datasets:
    X_orig,y_orig = get_data(name)
    X_orig = X_orig[:5000]
    y_orig = y_orig[:5000]
    training_percentage = 0.8

    for nois in [0, 0.2, 0.3]:
        train_patime = []
        test_patime = []
        n_sv_pa_ramp = []
        accuracy_pa_ramp = []
        for T in range(3):
            
            X_all, y_all = pynolca.preprocessing.shuffle(X_orig, y_orig)
            num = int(training_percentage * len(y_all))
            X, y = X_all[: num + 1], y_all[: num + 1]
            y = y * np.random.choice([-1,1], size = len(y), p = [nois, 1 - nois])
            X_test, y_test = X_all[num: ], y_all[num: ]
            # set model parameters 
            arg_kernel = {'name':'rbf','par':1} # kernel parameter
            t = 1.0 # parameter of heat kernel 
            arg_model = {'gamma_A':0, 'gamma_I':0,'arg_kernel':arg_kernel,'t':t}
            arg_alg = {'maxIte':50}
            # training 
            tim1 = time.time()
            model,iteInf = train_ramp(X,y,arg_model,arg_alg)
            train_patime.append(time.time()-tim1)
            # precision on train set 
            classifier = model['f']
            alpha = model['alpha']
            n_sv_pa_ramp.append(len(list(np.where(alpha))[0]))

            #y_pred =   classifier(X_test,alpha)  # predicted labels 
            tim2 = time.time()
            accuracy_pa_ramp.append(sum(classifier(X_test,alpha).flatten() == y_test) * 1.0 / len(y_test))
            test_patime.append(time.time()-tim2)

        print(accuracy_pa_ramp,n_sv_pa_ramp,test_patime,train_patime)
        # Saving the objects:
        with open('batch_nois_{}_letters.pkl'.format(int(nois*100)), 'wb') as f:  
            pickle.dump([accuracy_pa_ramp,n_sv_pa_ramp,test_patime,train_patime], f)



