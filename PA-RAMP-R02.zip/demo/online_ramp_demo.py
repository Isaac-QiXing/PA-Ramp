from os import write
import numpy as np
import matplotlib.pyplot as plt
from numpy.core.fromnumeric import shape
import pynolca
import sklearn.datasets as datasets
import time
import random as rnd
from sklearn.model_selection import KFold
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
import pickle
import multiprocessing as mp
import random

class Online_ramp:
    # NORMA for ramp
    def __init__(self, kernel):
        self.kernel = kernel
        self.num_errors = 0
        self.error_rates = []
        self.current_step = 0
        self.test_error_rates = []
        self.test_error =0
        self.timeloss =[]
        
    def fit(self, X, y, learning_rate, reg_coefficient, trunc, window,X_test,y_test, open):
        self.X = X
        self.y = y
        self.window = window
        self.learning_rate = learning_rate
        self.reg_coefficient = reg_coefficient
        self.alpha = np.zeros(len(self.y))
        i_times = 1
       
        for t in range(0, len(self.y)):
            self.current_step += 1
            if t == 0:
                self.alpha[t] = self.learning_rate * self.y[t]
                pred = 0
                self.num_errors += 1
            else:    
                pred = self.predict(self.X[t])
            if pred * self.y[t] < 0:
                self.num_errors += 1
            self.error_rates.append(self.collect_error_rates())
            if pred * self.y[t] < 1:
                self.alpha[t] = -self.learning_rate * self.derivative_computing(pred, self.y[t])
            index = np.where(np.abs(self.alpha) < trunc)[0]
            self.alpha[index] = 0

            if open == 1:
                start = time.time()
                if (t+1)%8==0:
                    if y_test[(i_times-1)]*self.predict3(X_test[(i_times-1)]) < 0:
                        self.test_error +=1
                    self.test_error_rates.append(self.test_error * 1.0 /i_times)
                    i_times +=1
                end = time.time()
                self.timeloss.append(end - start)



    def is_two_power(self, x):
        if (x & (x-1)) == 0:
            return True
        else:
            return False
    
    def derivative_computing(self, x, y):
        derivative = 0
        if x * y < 1:
            derivative = -y
        return derivative
    
    def f(self, x):
        kernel_vectors = self.kernel.compute_kernel(self.X, x)
        return np.dot(self.alpha, kernel_vectors)
    


    def predict(self, x):
        
        if np.sum(self.alpha != 0) < self.window:
            index = np.array(np.array(np.where(self.alpha)).flatten())
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.dot(self.alpha[index], kernel_vectors)
        else:
            index = np.array(np.array(np.where(self.alpha)).flatten()[-self.window:])
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.dot(self.alpha[index], kernel_vectors)

    
    def predict2(self, x):
        if np.sum(self.alpha != 0) < self.window:
            predt = np.zeros(len(x))
            index = np.array(np.array(np.where(self.alpha)).flatten())
            for i in range(0,len(x),10):
                kernel_vectors = self.kernel.compute_kernel(self.X[index], x[i:i+10])
                predt[i:i+10] = np.sign(np.dot(self.alpha[index], kernel_vectors))
            return predt
        else:
            predt = np.zeros(len(x))
            index = np.array(np.array(np.where(self.alpha)).flatten()[-self.window:])
            for i in range(0,len(x),10):
                kernel_vectors = self.kernel.compute_kernel(self.X[index], x[i:i+10])
                predt[i:i+10] = np.sign(np.dot(self.alpha[index], kernel_vectors))
            return predt


    def predict3(self, x):
        
        if np.sum(self.alpha != 0) < self.window:
            index = np.array(np.array(np.where(self.alpha)).flatten())
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.sign(np.dot(self.alpha[index], kernel_vectors))
        else:
            index = np.array(np.array(np.where(self.alpha)).flatten()[-self.window:])
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.sign(np.dot(self.alpha[index], kernel_vectors))



    def collect_error_rates(self):
        return self.num_errors * 1.0 / self.current_step
    
    def get_num_sv(self):
        if np.sum(self.alpha != 0) < self.window:
            return np.sum(self.alpha!=0)
        else:
            return self.window

class Pegasos:
    
    def __init__(self, kernel):
        self.kernel = kernel
        self.error_rates = []
        self.errors = 0
        self.test_error_rates = []
        self.test_error =0
        self.timeloss =[]
    def fit(self, X, y, reg_coefficient, iterations, window,X_test,y_test, open):
        self.regularization_coefficient = reg_coefficient
        num_observations = len(y)
        self.window = window
        self.X = X
        i_times = 1
        self.weights = np.zeros(num_observations)
        for t in range(1, iterations + 1):
            index = t-1
            if t == 1:
                #index = np.random.randint(0, num_observations)
                decision = 0
                eta = 1.0 / (self.regularization_coefficient * t)
            else:
                #index = np.random.randint(0, num_observations)
                decision = y[index] * self.predict(X[index])
                eta = 1.0 / (self.regularization_coefficient * t)
            # if decision < 1:
            #     self.weights = (1 - 1/t)*self.weights + eta *y[index]
            #     if decision < 0:
            #         self.errors += 1
            # else:
            #     self.weights = (1 - 1/t)*self.weights        
            # self.error_rates.append(self.errors * 1.0 / t)
            

                
            if decision < 1:
                self.weights[index] += eta * y[index]
                if decision < 0:
                    self.errors += 1
            self.error_rates.append(self.errors * 1.0 / t)
            self.weights = (1 - eta * self.regularization_coefficient) * self.weights

            if open == 1:
                start = time.time()
                if t%8==0:
                    if y_test[i_times-1]*self.predict3(X_test[i_times-1]) <0:
                        self.test_error +=1
                    self.test_error_rates.append(self.test_error * 1.0 /i_times)
                    i_times +=1
                end = time.time()
                self.timeloss.append(end - start)





    def get_num_sv(self):
        if np.sum(self.weights != 0) < self.window:
            return np.sum(self.weights!=0)
        else:
            return self.window


    def predict(self, x):
        if np.sum(self.weights != 0) < self.window:
            index = np.array(np.array(np.where(self.weights)).flatten())
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.dot(self.weights[index], kernel_vectors)
        else:
            index = np.array(np.array(np.where(self.weights)).flatten()[-self.window:])
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.dot(self.weights[index], kernel_vectors)
    
           
    def predict2(self, x):
        if np.sum(self.weights != 0) < self.window:
            predt = np.zeros(len(x))
            index = np.array(np.array(np.where(self.weights)).flatten())
            for i in range(0,len(x),10):
                kernel_vectors = self.kernel.compute_kernel(self.X[index], x[i:i+10])
                predt[i:i+10] = np.sign(np.dot((self.weights[index]), kernel_vectors))
            return predt
        else:
            predt = np.zeros(len(x))
            index = np.array(np.array(np.where(self.weights)).flatten()[-self.window:])
            for i in range(len(x),10):
                kernel_vectors = self.kernel.compute_kernel(self.X[index], x[i:i+10])
                predt[i:i+10] = np.sign(np.dot((self.weights[index]), kernel_vectors))
            return predt


    def predict3(self, x):
        if np.sum(self.weights != 0) < self.window:
            index = np.array(np.array(np.where(self.weights)).flatten())
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.sign(np.dot(self.weights[index], kernel_vectors))
        else:
            index = np.array(np.array(np.where(self.weights)).flatten()[-self.window:])
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.sign(np.dot(self.weights[index], kernel_vectors))


class PassiveAggressive_Ramp:

    def __init__(self, kernel, s):
        self.kernel = kernel
        self.error_rates = []
        self.errors = 0
        self.alpha = None
        self.s = s
        self.test_error_rates = []
        self.test_error =0
        self.timeloss =[]

    def fit(self, X, y,window,X_test,y_test, open):
        self.alpha = np.zeros(len(y))
        self.X = X
        self.window = window
        num_observations = len(y)
        i_times = 1
        for t in range(0, num_observations):
            index = t
            if t == 0:
                loss = 1
            else:
                loss = np.maximum(0, 1-y[index] * self.predict(self.X[index]))
            if y[index] * self.predict(self.X[index]) < 0:
                self.errors += 1
            if 0 < loss < (1 - self.s):
                tau = loss *  1.0 / kernel.compute_kernel(self.X[index], self.X[index])
                self.alpha[index] = tau * y[index]
            self.error_rates.append(self.errors * 1.0 / (t + 1))
            if open == 1:
                start = time.time()
                if (t+1)%8==0:
                    if y_test[i_times-1]*self.predict3(X_test[i_times-1]) <0:
                        self.test_error +=1
                    self.test_error_rates.append(self.test_error * 1.0 /i_times)
                    i_times +=1
                end = time.time()
                self.timeloss.append(end - start)


    def predict(self, x):
        if np.sum(self.alpha != 0) < self.window:
            index = np.array(np.array(np.where(self.alpha)).flatten())
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.dot(self.alpha[index], kernel_vectors)
        else:
            index = np.array(np.array(np.where(self.alpha)).flatten()[-self.window:])
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.dot(self.alpha[index], kernel_vectors)

    def predict2(self, x):
        if np.sum(self.alpha != 0) < self.window:
            predt = np.zeros(len(x))
            index = np.array(np.array(np.where(self.alpha)).flatten())
            for i in range(0,len(x),10):
                kernel_vectors = self.kernel.compute_kernel(self.X[index], x[i:i+10])
                predt[i:i+10] = np.sign(np.dot(self.alpha[index], kernel_vectors))
            return predt
        else:
            predt = np.zeros(len(x))
            index = np.array(np.array(np.where(self.alpha)).flatten()[-self.window:])
            for i in range(0,len(x),10):
                kernel_vectors = self.kernel.compute_kernel(self.X[index], x[i:i+10])
                predt[i:i+10] = np.sign(np.dot(self.alpha[index], kernel_vectors))    
            return predt

    def predict3(self, x):
        if np.sum(self.alpha != 0) < self.window:
            index = np.array(np.array(np.where(self.alpha)).flatten())
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.sign(np.dot(self.alpha[index], kernel_vectors))
        else:
            index = np.array(np.array(np.where(self.alpha)).flatten()[-self.window:])
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.sign(np.dot(self.alpha[index], kernel_vectors))   

    def get_num_sv(self):
        if np.sum(self.alpha != 0) < self.window:
            return np.sum(self.alpha!=0)
        else:
            return self.window

class KernelPerceptron:
    
    def __init__(self, kernel):
        self.kernel = kernel
        self.error_rates = []
        self.errors = 0
        self.test_error_rates = []
        self.test_error =0
        self.timeloss =[]

    def fit(self, X, y, learning_rate, window,X_test,y_test, open):
        self.window = window
        self.X = X
        num_observations = len(y)
        self.alpha = np.zeros(num_observations)
        i_times = 1
        for i in range(0, num_observations):
            index = i
            if i == 0:
                self.alpha[0] += 1
            if self.predict(self.X[index]) * y[index] <= 0:
                self.alpha[index] += learning_rate * y[index]
                self.errors += 1
            self.error_rates.append(self.errors * 1.0 / (i+1))
            if open == 1:
                start = time.time()
                if (i+1)%8==0:
                    if y_test[i_times-1]*self.predict(X_test[i_times-1]) <0:
                        self.test_error +=1
                    self.test_error_rates.append(self.test_error * 1.0 /i_times)
                    i_times +=1
                end = time.time()
                self.timeloss.append(end - start)


    def predict(self, x):
        if np.sum(self.alpha != 0) < self.window:
            index = np.array(np.array(np.where(self.alpha)).flatten())
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.sign(np.dot(self.alpha[index], kernel_vectors))
        else:
            index = np.array(np.array(np.where(self.alpha)).flatten()[-self.window:])
            kernel_vectors = self.kernel.compute_kernel(self.X[index], x)
            return np.sign(np.dot(self.alpha[index], kernel_vectors))

    
    def predict2(self, x):
        if np.sum(self.alpha != 0) < self.window:
            predt = np.zeros(len(x))
            index = np.array(np.array(np.where(self.alpha)).flatten())
            for i in range(0,len(x),10):
                kernel_vectors = self.kernel.compute_kernel(self.X[index], x[i:i+10])
                predt[i:i+10] = np.sign(np.dot(self.alpha[index], kernel_vectors))
            return predt
        else:
            predt = np.zeros(len(x))
            index = np.array(np.array(np.where(self.alpha)).flatten()[-self.window:])
            for i in range(0,len(x),10):
                kernel_vectors = self.kernel.compute_kernel(self.X[index], x[i:i+10])
                predt[i:i+10] = np.sign(np.dot(self.alpha[index], kernel_vectors))
            return predt



    def get_num_sv(self):
        if np.sum(self.alpha != 0) < self.window:
            return np.sum(self.alpha!=0)
        else:
            return self.window
            
def parameter_selection_pa_ramp(X, y, kernel, hyperparameters, folds = 5,windows=10):
    s_grid = hyperparameters["s"]
    window = windows
    num_observations = len(y)
    accuracy_overall = 0
    combination = []
    for s in s_grid:
        kf = KFold( n_splits = folds, shuffle = True)
        accuracy_collection = []
        for train_index, validation_index in kf.split(X):
            X_train, X_validation = X[train_index], X[validation_index]
            y_train, y_validation = y[train_index], y[validation_index]
            clf = PassiveAggressive_Ramp(kernel, s = s)
            clf.fit(X_train, y_train,window =window,X_test=None, y_test=None, open=0)
            accuracy_collection.append(sum(clf.predict2(X_validation) == y_validation) * 1.0 / len(y_validation))
        accuracy_mean = np.array(accuracy_collection).mean()
        if accuracy_mean > accuracy_overall:
            accuracy_overall = accuracy_mean
            combination = [s]    
    return accuracy_overall, combination

def parameter_selection_online(X, y, kernel, hyperparameters, folds = 5, windows =10):
    reg_coefficient_grid, learning_rate_grid, trunc_grid = hyperparameters["reg_coefficient"], hyperparameters["learning_rate"], hyperparameters["trunc"]
    num_observations = len(y)
    accuracy_overall = 0
    window = windows
    combination = [reg_coefficient_grid[0], learning_rate_grid[0], trunc_grid[0]]
    for reg_coefficient in reg_coefficient_grid:
        for learning_rate in learning_rate_grid:
            for trunc in trunc_grid:
                kf = KFold( n_splits = folds, shuffle = True)
                accuracy_collection = []
                for train_index, validation_index in kf.split(X):
                    X_train, X_validation = X[train_index], X[validation_index]
                    y_train, y_validation = y[train_index], y[validation_index]
                    clf = Online_ramp(kernel)
                    clf.fit(X_train, y_train, learning_rate = learning_rate, reg_coefficient = reg_coefficient, trunc = trunc, window = window,X_test=None, y_test=None, open=0)
                    accuracy_collection.append(sum(clf.predict2(X_validation) == y_validation) * 1.0 / len(y_validation))
                accuracy_mean = np.array(accuracy_collection).mean()
                if accuracy_mean > accuracy_overall:
                    accuracy_overall = accuracy_mean
                    combination = [reg_coefficient, learning_rate, trunc]
    return accuracy_overall, combination

def parameter_selection_pegasos(X, y, kernel, hyperparameters, folds = 5, windows =10):
    reg_coefficient_grid = hyperparameters["reg_coefficient"]
    num_observations = len(y)
    accuracy_overall = 0
    window = windows
    for reg_coefficient in reg_coefficient_grid:
        kf = KFold( n_splits = folds, shuffle = True)
        accuracy_collection = []
        for train_index, validation_index in kf.split(X):
            X_train, X_validation = X[train_index], X[validation_index]
            y_train, y_validation = y[train_index], y[validation_index]
            clf = Pegasos(kernel)
            clf.fit(X_train, y_train, reg_coefficient = reg_coefficient, iterations = len(y_train), window = window,X_test=None, y_test=None, open=0)
            accuracy_collection.append(sum(clf.predict2(X_validation) == y_validation) * 1.0 / len(y_validation))
        accuracy_mean = np.array(accuracy_collection).mean()
        if accuracy_mean > accuracy_overall:
            accuracy_overall = accuracy_mean
            combination = [reg_coefficient]
    return accuracy_overall, combination

def parameter_selection_perceptron(X, y, kernel, hyperparameters, folds = 5, windows =10):
    learning_rate_grid = hyperparameters["learning_rate"]
    num_observations = len(y)
    accuracy_overall = 0
    window = windows
    for learning_rate in learning_rate_grid:
        kf = KFold( n_splits = folds, shuffle = True)
        accuracy_collection = []
        for train_index, validation_index in kf.split(X):
            X_train, X_validation = X[train_index], X[validation_index]
            y_train, y_validation = y[train_index], y[validation_index]
            clf = KernelPerceptron(kernel)
            clf.fit(X_train, y_train, learning_rate = learning_rate, window = window,X_test=None, y_test=None, open=0)
            accuracy_collection.append(sum(clf.predict2(X_validation) == y_validation) * 1.0 / len(y_validation))
        accuracy_mean = np.array(accuracy_collection).mean()
        if accuracy_mean > accuracy_overall:
            accuracy_overall = accuracy_mean
            combination = [learning_rate]
    return accuracy_overall, combination

def Comparison(X, y, training_percentage, validation_num, noise_proportion, kernel, hyperparameters_online,
               hyperparameters_pegasos, hyperparameters_perceptron,  hyperparameters_pa_ramp, fold, T , window): 
     
    accuracy_online = []
    accuracy_pegasos = []
    accuracy_perceptron = []
    accuracy_pa_ramp = []
    
    n_sv_online = []
    n_sv_pegasos = []
    n_sv_perceptron = []
    n_sv_pa_ramp = []
    
    selection_onlinetime = []
    selection_pegasostime = []
    selection_perceptrontime  = []
    selection_patime = []

    train_onlinetime = []
    train_pegasostime = []
    train_perceptrontime  = []
    train_patime = []

    
    time_online = []
    time_pegasos = []
    time_perceptron = []
    time_pa_ramp = []
    
    loss = []
    
    

    X_orig = X.copy()
    y_orig = y.copy()
    for t in range(T):
        loss_online = []
        loss_pegasos = []
        loss_perceptron = []
        loss_pa_ramp = []

        loss_test_online = []
        loss_test_pegasos = []
        loss_test_perceptron = []
        loss_test_pa_ramp = []




        X_all, y_all = pynolca.preprocessing.shuffle(X_orig, y_orig)
        num = int(training_percentage * len(y_all))
        X, y = X_all[: num + 1], y_all[: num + 1]
        # shutnum = int(len(y)*0.2)
        # X_c, y_c = X[: shutnum], y[: shutnum]
        # X_n, y_n = X[shutnum: ], y[shutnum: ]
        # y_n



        # leny = len(y)
        # shutnum = int(len(y)*0.2)
        # y_clear = y[:shutnum]
        # y = y[shutnum:]
        y = y * np.random.choice([-1,1], size = len(y), p = [noise_proportion, 1 - noise_proportion])
        # y = y * np.random.choice([-1,1], size = len(y), p = [noise_proportion/(1-0.2), 1 - noise_proportion/(1-0.2)])
        # y = np.hstack((y_clear,y))


        X_test, y_test = X_all[num: ], y_all[num: ]
        X_verification,y_verification = X_test[:int(len(X_test)/2)], y_test[:int(len(y_test)/2)]
        #NORMA
        start1 = time.time()
        _, combination = parameter_selection_online(X_verification[:validation_num + 1], y_verification[:validation_num + 1], kernel, hyperparameters_online, folds = fold, windows = window)
        end1 = time.time()
        selection_onlinetime.append(end1 - start1)
        print("best for online", combination)

        start2 = time.time()
        clf = Online_ramp(kernel=kernel)
        clf.fit(X, y, reg_coefficient=combination[0], learning_rate=combination[1], trunc=combination[2], window = window,X_test=X_verification,y_test=y_verification, open=1)
        end2 = time.time()
        train_onlinetime.append(end2 - start2- np.sum(clf.timeloss))
        loss_online.append(clf.error_rates)
        loss_test_online.append(clf.test_error_rates)

        start = time.time()
        accuracy_online.append(sum(clf.predict2(X_test) == y_test) * 1.0 / len(y_test))
        end = time.time()
        time_online.append(end - start)
        n_sv_online.append(clf.get_num_sv())
        

        #Pegasos
        start1 = time.time()
        _, combination = parameter_selection_pegasos(X_verification[:validation_num + 1], y_verification[:validation_num + 1], kernel, hyperparameters_pegasos, folds = fold, windows = window)
        end1 = time.time()
        print("best for pegasos", combination)
        selection_pegasostime.append(end1 - start1)

        start2 = time.time()
        clf = Pegasos(kernel)
        clf.fit(X, y, reg_coefficient = combination[0], iterations = len(y), window = window ,X_test=X_verification,y_test=y_verification, open=1)
        end2 = time.time()
        train_pegasostime.append(end2 - start2 - np.sum(clf.timeloss))
        loss_pegasos.append(clf.error_rates)
        loss_test_pegasos.append(clf.test_error_rates)



        start = time.time()
        accuracy_pegasos.append(sum(clf.predict2(X_test) == y_test) * 1.0 / len(y_test))
        end = time.time()
        time_pegasos.append(end - start)
        n_sv_pegasos.append(clf.get_num_sv())
        
        # Perceptron
        start1 = time.time()
        _, combination = parameter_selection_perceptron(X_verification[:validation_num + 1], y_verification[:validation_num + 1], kernel, hyperparameters_perceptron, folds = fold, windows = window)
        end1 = time.time()
        print("best for perceptron", combination)
        selection_perceptrontime.append(end1-start1)

        start2 = time.time()
        clf = KernelPerceptron(kernel)
        clf.fit(X, y, learning_rate = combination[0], window = window,X_test=X_verification,y_test=y_verification, open=1)
        end2 = time.time()
        train_perceptrontime.append(end2 -start2- np.sum(clf.timeloss))
        loss_perceptron.append(clf.error_rates)
        loss_test_perceptron.append(clf.test_error_rates)

        start = time.time()
        accuracy_perceptron.append(sum(clf.predict2(X_test) == y_test) * 1.0 / len(y_test))
        end = time.time()
        time_perceptron.append(end - start)
        n_sv_perceptron.append(clf.get_num_sv())
        
        # PA ramp
        start1 = time.time()
        _, combination = parameter_selection_pa_ramp(X_verification[:validation_num + 1], y_verification[:validation_num + 1], kernel, hyperparameters_pa_ramp, folds = fold, windows = window)
        end1 = time.time()
        print("best for pa-ramp", combination)
        selection_patime.append(end1-start1)
        start2 = time.time()
        clf = PassiveAggressive_Ramp(kernel, s = combination[0])
        clf.fit(X, y,window = window,X_test=X_verification,y_test=y_verification, open=1)
        end2 = time.time()
        train_patime.append(end2 - start2- np.sum(clf.timeloss))
        loss_pa_ramp.append(clf.error_rates)
        loss_test_pa_ramp.append(clf.test_error_rates)

        start = time.time()
        accuracy_pa_ramp.append(sum(clf.predict2(X_test) == y_test) * 1.0 / len(y_test))
        end = time.time()
        time_pa_ramp.append(end - start)
        n_sv_pa_ramp.append(clf.get_num_sv())
        
        loss.append([loss_online, loss_pegasos, loss_perceptron, loss_pa_ramp,loss_test_online,loss_test_pegasos,loss_test_perceptron,loss_test_pa_ramp])
    

     
        
    return accuracy_online,  accuracy_pegasos,  accuracy_perceptron, accuracy_pa_ramp, n_sv_online,  \
           n_sv_pegasos,  n_sv_perceptron, n_sv_pa_ramp, time_online, time_pegasos,  time_perceptron, \
            time_pa_ramp,selection_onlinetime, selection_pegasostime, selection_perceptrontime , selection_patime ,\
            train_onlinetime , train_pegasostime , train_perceptrontime , train_patime , loss\



def get_data(dataname):
    if dataname == 'Adult':
        # Adult Data
        X = np.load("datasets/adultdata/adultData.npy")
        X_test = np.load("datasets/adultdata/adultTest.npy")
        y = np.load("datasets/adultdata/adultData_label.npy")
        y_test = np.load("datasets/adultdata/adultTest_label.npy")
        X_orig = np.vstack((X, X_test))
        X_orig = (X_orig - X_orig.mean(axis = 0)) / X_orig.std(axis = 0)
        y_orig = np.hstack((y, y_test))
        
    if dataname == 'intel':
        #inteldata
        df = pd.read_csv("datasets/inteldata/inteldata.csv")
        X_orig = np.array(df[df.columns[1:5]])
        X_orig = (X_orig - X_orig.mean(axis = 0)) / X_orig.std(axis = 0)
        y_orig = np.array(df[df.columns[-1]])
    if dataname == 'kdd':
        #KDDdata
        df = pd.read_csv("datasets/KDDdata/KDDdata.csv")
        X_orig = np.array(df[df.columns[0:-1]])
        X_orig = (X_orig - X_orig.mean(axis = 0))
        y_orig = np.array(df[df.columns[-1]])
    if dataname == 'letter':
        # Letters Data
        # Character
        X_orig = np.loadtxt('datasets/letter-recognition.data',
                        usecols = (range(1,16)),
                        delimiter=",")
        X_orig = (X_orig - X_orig.mean(axis = 1, keepdims=True)) / X_orig.std(axis = 1, keepdims=True)
        # Load the true labels
        y = np.loadtxt("datasets/letter-recognition.data",
                        usecols = (0,),
                        delimiter=",", dtype='str')

        idx_set = np.array(['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'])
        y_orig = -1 * np.ones(len(y), dtype = np.int16)
        for i in range(len(y)):
            if y[i] in idx_set:
                y_orig[i] = 1
    if dataname == 'occupancy':
        # Occupancy

        df_1 = pd.read_csv("datasets/occupancy/datatraining.txt")
        df_2 = pd.read_csv("datasets/occupancy/datatest.txt")
        df_3 = pd.read_csv("datasets/occupancy/datatest2.txt")
        df = pd.concat([df_1, df_2, df_3], ignore_index=True)
        X_orig = np.array(df[df.columns[1:6]])
        X_orig = (X_orig - X_orig.mean(axis = 0)) / X_orig.std(axis = 0)
        y_orig = np.array(df[df.columns[-1]], dtype=np.int16)
        y_orig = y_orig * 2 - 1
    if dataname == 'RBF':
        # RBF
        df = pd.read_csv("datasets/RandomRBF/RandomRBF_10.csv")
        X_orig = np.array(df[df.columns[0:10]])
        y_orig = np.array(df[df.columns[-1]])
    return X_orig,y_orig


#demo_letter
datasets = ['letter']
    

# datasets = ['Adult', 'intel', 'kdd', 'letter', 'occupancy', 'RBF']
for name in datasets:
    X_all,y_all =get_data(name)
    kernel = pynolca.kernel.RBF_Kernel()
    s_grid = np.linspace(-1,0,10)
    reg_coefficient_grid = np.power(10, np.arange(-3, -1, dtype=np.float32))
    learning_rate_grid = np.power(10, np.arange(-5, -3, dtype=np.float32))
    trunc_grid = np.array([0,0])

    window = 100000

    hyperparameters_online = {"reg_coefficient": reg_coefficient_grid, "learning_rate": learning_rate_grid, 
                            "trunc": trunc_grid}

    hyperparameters_pegasos = {"reg_coefficient": reg_coefficient_grid}

    hyperparameters_perceptron = {"learning_rate": learning_rate_grid}
    hyperparameters_pa_ramp = {"s": s_grid}



    accuracy_online, accuracy_pegasos, accuracy_perceptron, accuracy_pa_ramp, n_sv_online,\
    n_sv_pegasos,  n_sv_perceptron, n_sv_pa_ramp,time_online ,time_pegasos ,time_perceptron,time_pa_ramp,\
    selection_onlinetime ,selection_pegasostime ,selection_perceptrontime  ,selection_patime ,train_onlinetime ,train_pegasostime ,train_perceptrontime ,train_patime ,loss=\
    Comparison(X_all, y_all, training_percentage = 0.8, validation_num =int(len(X_all) * 0.2), 
                hyperparameters_pa_ramp = hyperparameters_pa_ramp, noise_proportion = 0.2, kernel = kernel, 
            hyperparameters_perceptron=hyperparameters_perceptron,hyperparameters_online = hyperparameters_online, 
            hyperparameters_pegasos = hyperparameters_pegasos, fold = 5, T = 3, window=100000)


    print("Online-Ramp accuracy: ", accuracy_online, "average: ", np.array(accuracy_online).mean(), "std: ", np.array(accuracy_online).std(),\
        "Num. of SVs: ", n_sv_online, "average: ", np.array(n_sv_online).mean(), "std: ", np.array(n_sv_online).std(),\
        "time: ", time_online, "average: ", np.array(time_online).mean(), "std: ", np.array(time_online).std(),\
        "selection_time: ", selection_onlinetime , "average: ", np.array(selection_onlinetime ).mean(), "std: ", np.array(selection_onlinetime ).std(),\
        "train_time: ", train_onlinetime, "average: ", np.array(train_onlinetime).mean(), "std: ", np.array(train_onlinetime).std())


    print("Pegasos accuracy: ", accuracy_pegasos, "average: ", np.array(accuracy_pegasos).mean(), "std: ", np.array(accuracy_pegasos).std(),\
        "Num. of SVs: ", n_sv_pegasos, "average: ", np.array(n_sv_pegasos).mean(), "std: ", np.array(n_sv_pegasos).std(),\
        "time: ", time_pegasos, "average: ", np.array(time_pegasos).mean(), "std: ", np.array(time_pegasos).std(),\
        "selection_time: ", selection_pegasostime , "average: ", np.array(selection_pegasostime ).mean(), "std: ", np.array(selection_pegasostime).std(),\
        "train_time: ", train_pegasostime, "average: ", np.array(train_pegasostime).mean(), "std: ", np.array(train_pegasostime).std())


    print("Perceptron accuracy: ", accuracy_perceptron, "average: ", np.array(accuracy_perceptron).mean(), "std: ", np.array(accuracy_perceptron).std(),\
        "Num. of SVs: ", n_sv_perceptron, "average: ", np.array(n_sv_perceptron).mean(), "std: ", np.array(n_sv_perceptron).std(),\
        "time: ", time_perceptron, "average: ", np.array(time_perceptron).mean(), "std: ", np.array(time_perceptron).std(),\
        "selection_time: ", selection_perceptrontime, "average: ", np.array(selection_perceptrontime).mean(), "std: ", np.array(selection_perceptrontime).std(),\
        "train_time: ", train_perceptrontime, "average: ", np.array(train_perceptrontime).mean(), "std: ", np.array(train_perceptrontime).std())

    print("PassiveAggressive-Ramp accuracy: ", accuracy_pa_ramp, "average: ", np.array(accuracy_pa_ramp).mean(), "std: ", np.array(accuracy_pa_ramp).std(),\
        "Num. of SVs: ", n_sv_pa_ramp, "average: ", np.array(n_sv_pa_ramp).mean(),  "std: ", np.array(n_sv_pa_ramp).std(), \
        "time: ", time_pa_ramp, "average: ", np.array(time_pa_ramp).mean(), "std: ", np.array(time_pa_ramp).std(),\
        "selection_time: ", selection_patime, "average: ", np.array(selection_patime).mean(), "std: ", np.array(selection_patime).std(),\
        "train_time: ", train_patime, "average: ", np.array(train_patime).mean(), "std: ", np.array(train_patime).std())




    # Saving the objects:
    with open('nois_20_clear_0_{}.pkl'.format(name), 'wb') as f:  
        pickle.dump([accuracy_online, accuracy_pegasos, accuracy_perceptron,\
            accuracy_pa_ramp, n_sv_online,n_sv_pegasos,  n_sv_perceptron, \
            n_sv_pa_ramp,time_online ,time_pegasos ,time_perceptron,time_pa_ramp,\
            selection_onlinetime ,selection_pegasostime ,selection_perceptrontime  ,\
            selection_patime ,train_onlinetime ,train_pegasostime ,train_perceptrontime ,\
            train_patime,loss], f)





    L = len(loss[0][0][0])
    T = 3
    loss_online = np.zeros((T, L))
    loss_pegasos = np.zeros((T, L))
    loss_pa_ramp = np.zeros((T, L))
    loss_perceptron = np.zeros((T, L))
    for i in range(len(loss)):
        for j in range(len(loss[i])):
            if j == 0:
                loss_online[i, :] = loss[i][j][0]
            elif j == 1:
                loss_pegasos[i, :] = loss[i][j][0]
            elif j == 3:
                loss_pa_ramp[i, :] = loss[i][j][0]
            elif j == 2:
                loss_perceptron[i, :] = loss[i][j][0]

                
                
    fig = plt.figure()
    ax = fig.add_subplot(111)

    y = loss_pegasos.mean(axis=0).flatten()
    n = len(y)
    inter =10
    y = y[0:n:inter]

    x = range(0,n,inter)
    std = loss_pegasos.std(axis=0).flatten()
    std = std[0:n:inter]
    ax.plot(x,y, label = "Pegasos")
    #print(y[-1], std[-1])
    plt.fill_between(x, y - std, y + std,alpha=0.2)

    y = loss_perceptron.mean(axis=0).flatten()
    n = len(y)
    inter =10
    y = y[0:n:inter]

    x = range(0,n,inter)
    std = loss_perceptron.std(axis=0).flatten()
    std = std[0:n:inter]
    #print(y[-1], std[-1])
    ax.plot(x,y, label = "Perceptron")
    ax.fill_between(x, y - std, y + std,alpha=0.2)

    y = loss_online.mean(axis=0).flatten()
    n = len(y)
    inter =10
    y = y[0:n:inter]
    x = range(0,n,inter)
    std = loss_online.std(axis=0).flatten()
    std = std[0:n:inter]
    #print(y[-1], std[-1])
    ax.plot(x,y, label = "NORMA")
    ax.fill_between(x, y - std, y + std,alpha=0.2)
    ax.set_xlabel('Number of iterations', fontsize = 16)
    ax.set_ylabel('Misclassification rate', fontsize = 16)

    y = loss_pa_ramp.mean(axis=0).flatten()
    n = len(y)
    inter = 10
    y = y[0:n:inter]

    x = range(0,n,inter)
    std = loss_pa_ramp.std(axis=0).flatten()
    std = std[0:n:inter]
    #print(y[-1], std[-1])
    ax.plot(x,y, label = "PA-Ramp")
    ax.fill_between(x, y - std, y + std,alpha=0.2)
    ax.legend(fontsize = 12)

    pp = PdfPages('nois_20_clear_0_{}.format(name)pdf')
    pp.savefig(fig, bbox_inches='tight')
    pp.close()





    L = int(len(y_all)*0.1)

    T = 3
    loss_online = np.zeros((T, L))
    loss_pegasos = np.zeros((T, L))
    loss_pa_ramp = np.zeros((T, L))
    loss_perceptron = np.zeros((T, L))
    for i in range(len(loss)):
        for j in range(len(loss[i])):
            if j == 4:
                loss_online[i, :] = loss[i][j][0]
            elif j == 5:
                loss_pegasos[i, :] = loss[i][j][0]
            elif j == 7:
                loss_pa_ramp[i, :] = loss[i][j][0]
            elif j == 6:
                loss_perceptron[i, :] = loss[i][j][0]

                
                
    fig = plt.figure()
    ax = fig.add_subplot(111)

    y = loss_pegasos.mean(axis=0).flatten()
    n = len(y)
    inter = 5
    y = y[0:n:inter]

    x = range(0,n,inter)
    std = loss_pegasos.std(axis=0).flatten()
    std = std[0:n:inter]
    ax.plot(x,y, label = "Pegasos")
    #print(y[-1], std[-1])
    plt.fill_between(x, y - std, y + std,alpha=0.2)

    y = loss_perceptron.mean(axis=0).flatten()
    n = len(y)
    inter = 5
    y = y[0:n:inter]

    x = range(0,n,inter)
    std = loss_perceptron.std(axis=0).flatten()
    std = std[0:n:inter]
    #print(y[-1], std[-1])
    ax.plot(x,y, label = "Perceptron")
    ax.fill_between(x, y - std, y + std,alpha=0.2)

    y = loss_online.mean(axis=0).flatten()
    n = len(y)
    inter = 5
    y = y[0:n:inter]
    x = range(0,n,inter)
    std = loss_online.std(axis=0).flatten()
    std = std[0:n:inter]
    #print(y[-1], std[-1])
    ax.plot(x,y, label = "NORMA")
    ax.fill_between(x, y - std, y + std,alpha=0.2)
    ax.set_xlabel('Number of iterations', fontsize = 16)
    ax.set_ylabel('Misclassification rate', fontsize = 16)

    y = loss_pa_ramp.mean(axis=0).flatten()
    n = len(y)
    inter = 5
    y = y[0:n:inter]

    x = range(0,n,inter)
    std = loss_pa_ramp.std(axis=0).flatten()
    std = std[0:n:inter]
    #print(y[-1], std[-1])
    ax.plot(x,y, label = "PA-Ramp")
    ax.fill_between(x, y - std, y + std,alpha=0.2)

    ax.legend(fontsize = 12)
        
    pp = PdfPages('nois_20_clear_0_{}_test.pdf'.format(name))
    pp.savefig(fig, bbox_inches='tight')
    pp.close()



